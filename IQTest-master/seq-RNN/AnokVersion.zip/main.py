
import os
import shutil
import argparse
import random
import numpy as np
import torch
import time
import json
import math
from modeling import SeqRNN
from modeling import SeqData,SeqData_norm1
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

# data_file={'train':'seq-train.json','valid':'seq-valid.json','test':'seq-test.json'}
data_file={'train':'seq-train.json','valid':'seq-valid.json'}

criterion = nn.NLLLoss()
# Number of features used as input. (Number of columns)
INPUT_SIZE = 3
OUTPUT_SIZE = 1
# Number of previous time stamps taken into account.
# HIDDEN_SIZE = 64
# Number of stacked rnn layers.
NUM_LAYERS = 1
activation=torch.nn.functional.relu

def timeSince(since):
    now = time.time()
    s = now - since
    m = math.floor(s / 60)
    s -= m * 60
    return '%dm %ds' % (m, s)

def train(seqrnn,args,line,category):
    hidden = seqrnn.initHidden()
    seqrnn.zero_grad()
    for i in range(line.size()[0]):
        output, hidden = seqrnn(line[i].float(), hidden)
    # print(output.item(),category.item())
    # loss = criterion(output, category)
    # print(output,category)
    loss = (output-category)**2
    loss.backward()
    # Add parameters' gradients to their values, multiplied by learning rate
    for p in seqrnn.parameters():
        p.data.add_(p.grad.data, alpha=-args.lr)
    return output, loss.item()

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--data_dir",
                        default='../data',
                        type=str,
                        help="The input data dir. Should contain the input json file")
    parser.add_argument("--output_dir",
                        default='res/',
                        type=str,
                        help="The output directory where the model checkpoints will be written.")

    parser.add_argument("--lr",
                        default=0.005,
                        type=float,
                        help="The initial learning rate for Adam.")
    parser.add_argument("--hidden_size",
                        default=32,
                        type=int,
                        help="Hidden size for rnn")
    parser.add_argument("--niters",
                        default=int(5e4),
                        type=int,
                        help="Hidden size for rnn")
    parser.add_argument("--norm", # 0 for minmax, 1 for length-based normalize
                        default=0, 
                        type=float,
                        help="Hidden size for rnn")

    args = parser.parse_args()
    device = torch.device('cpu')
    if args.norm==0:
        seq_train_data = SeqData(args.data_dir, data_file['train'])
        seq_valid_data = SeqData(args.data_dir, data_file['valid'])
    else:
        seq_train_data = SeqData_norm1(args.data_dir, data_file['train'])
        seq_valid_data = SeqData_norm1(args.data_dir, data_file['valid'])
    trainloader = DataLoader(seq_train_data, batch_size=1,shuffle=True)
    # data=seq_train_data.nromByLen(0)
    # dataiter=iter(trainloader)
    # a=dataiter.next()
    
    # optimizer = Adam(optimizer_grouped_parameters,
    #                      lr=args.learning_rate,
    #                      t_total=t_total)

    seqrnn = SeqRNN(INPUT_SIZE, args.hidden_size, OUTPUT_SIZE)

    # n_iters = 500000
    # n_iters = int(4e4)
    n_iters = args.niters
    # print_every = 50000
    print_every = n_iters/10
    # plot_every = 10000
    plot_every = n_iters/40
    current_loss = 0
    curvad_loss=0
    all_losses = []
    vad_acc = []
    vad_loss=[]
    start = time.time()

    for t in range(n_iters + 1):
        data=seq_train_data.__getitem__(0)
        real_value=data[-1][-1][2]
        # print(data,real_value)
        # data=data[:-1]
        output, loss = train(seqrnn,args,data,real_value)
        current_loss += loss
        # if math.isnan(loss):
        #     print(output)
        #     print(loss)
        #     exit()

        # Print iter number, loss, name and guess
        if t % print_every == 0:
            guess=output
            correct = '✓' if guess == real_value else '✗ (%s)' % real_value
            # print('%d %d%% (%s) %.4f %s / %s %s' % (t, t / n_iters * 100, timeSince(start), loss, line, guess, correct))
            print('%d %d%% (%s) %.4f %s' % (t, t / n_iters * 100, timeSince(start), loss, correct))
        # Add current loss avg to list of losses
        if t % plot_every == 0 and t!=0:
            curlos=current_loss / plot_every
            
            data=seq_valid_data.__getitem__(0)
            real_value=data[-1][-1][2]
            output, curvad_loss = train(seqrnn,args,data,real_value)
            curacc=seq_valid_data.cal_accuracy(seqrnn)
            # print(curacc)
            # exit()
            all_losses.append(curlos)
            vad_loss.append(curvad_loss)
            vad_acc.append(curacc)
            current_loss = 0
            curvad_loss=0

        #debug
        # if args.norm==0:
        #     exit()
    print(vad_acc)

    fig, (ax1, ax2)= plt.subplots(1,2, figsize = (10,5))
    ax1.plot(all_losses,label='train loss')
    ax1.plot(vad_loss,label='valid loss')
    ax1.legend()
    ax2.plot(vad_acc)
    xList=[i for i in range(20)]
    yList=[vad_acc[i*2] for i in range(20)]
    for x, y in zip(xList, yList):
	    ax2.text(x*2, y, '%.1f'%(y*100), ha='center', va='bottom', fontsize=6)
    
    # plt.suptitle(str(n_iters/10000)+'w iters '+'lr'+str(args.lr)+'_hidden'+str(args.hidden_size)+'_norm'+str(int(args.norm)))
    plt.title(str(n_iters/10000)+'w iters '+'lr'+str(args.lr)+'_hidden'+str(args.hidden_size)+'_norm'+str(int(args.norm)),pad=20)
    plt.savefig('img/train_eval'+str(n_iters/10000)+'w_'+'lr'+str(args.lr)+'_hidden'+str(args.hidden_size)+'_norm'+str(int(args.norm))+'.png')
    plt.tight_layout()
    plt.show()

    print('saving model')
    torch.save(seqrnn.state_dict(), 'model/RNNmodel'+str(n_iters/10000)+'w_'+'lr'+str(args.lr)+'_hidden'+str(args.hidden_size)+'_norm'+str(args.norm)+'.pkl')
# model_object.load_state_dict(torch.load('RNNmodel.pkl'))


if __name__ == "__main__":
    main()



